# import micropython
from time import ticks_us, ticks_diff
from pyb import Pin, Timer, UART, ExtInt, I2C
from array import array
import task_share
import cotask
import struct

class PID: # abstract PID class

	def __init__(self, K_P, K_I, K_D, intLim, derAve):
		self.K_P = K_P
		self.K_I = K_I
		self.K_D = K_D
		self.intLim = intLim # integral limit.  When the integral effort reaches this value, the integral stops growing
		self.derAve = derAve # number of derivative values to average out when calculating derivative effort
		self.integral = 0
		self.prevError = 0
		self.timeStamp = ticks_us()
		self.der_list = array('i', derAve*[0]) # der list contains the most recent derivative effort values for averaging
		self.der_index = 0

	def zero(self):
		self.integral = 0

	def setTimeStamp(self):
		self.timeStamp = ticks_us()

	def setPID(self, K_P, K_I, K_D):
		self.K_P = K_P
		self.K_I = K_I
		self.K_D = K_D

	def calculate(self, error):
		deltaT = ticks_diff(ticks_us(), self.timeStamp)
		self.timeStamp = ticks_us()

		proEffort = self.K_P * error # proportional effort

		intEffort = 0 # integral effort
		if self.K_I > 0:
			self.integral += error * deltaT
			intEffort = self.K_I * self.integral / 1000000 # integral value is converted from microseconds
			if self.intLim > 0:
				if abs(intEffort) > self.intLim:
					self.integral -= error * deltaT # if integral effort is too high, undo the effects on the integral
					if intEffort > 0:
						intEffort = self.intLim
					else:
						intEffort = -1*self.intLim
		else:
			self.integral = 0

		derEffort = 0
		if self.K_D > 0:
			if deltaT > 0:
				self.der_list[self.der_index] = int(self.K_D * (error - self.prevError) / deltaT) # assign the next derivative in the list
				if self.der_index == self.derAve-1:
					self.der_index = 0 # reset the index
				else:
					self.der_index += 1 # increment the index
				der_total = 0
				for i in range(self.derAve):
					der_total += self.der_list[i]
				if der_total > 0:
					derEffort = int(der_total / self.derAve)
			self.prevError = error

		return int(proEffort + intEffort + derEffort)