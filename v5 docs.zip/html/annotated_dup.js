var annotated_dup =
[
    [ "Com_Task", null, [
      [ "Com_Task", "class_com___task_1_1_com___task.html", null ]
    ] ],
    [ "Controller", null, [
      [ "Controller", "class_controller_1_1_controller.html", "class_controller_1_1_controller" ]
    ] ],
    [ "Encoder", null, [
      [ "Encoder", "class_encoder_1_1_encoder.html", null ]
    ] ],
    [ "IMU_Tracker", null, [
      [ "IMU_Tracker", "class_i_m_u___tracker_1_1_i_m_u___tracker.html", null ]
    ] ],
    [ "IR_Sense_Task", null, [
      [ "IR_Sense_Task", "class_i_r___sense___task_1_1_i_r___sense___task.html", null ]
    ] ],
    [ "ME405 Term Project v5", null, [
      [ "Main", "class_m_e405_01_term_01_project_01v5_1_1_main.html", "class_m_e405_01_term_01_project_01v5_1_1_main" ]
    ] ],
    [ "Motor", null, [
      [ "Motor", "class_motor_1_1_motor.html", null ]
    ] ],
    [ "Motor_Task", null, [
      [ "Motor_Task", "class_motor___task_1_1_motor___task.html", null ]
    ] ],
    [ "PID", null, [
      [ "PID", "class_p_i_d_1_1_p_i_d.html", null ]
    ] ],
    [ "Ultra_Sense_Task", null, [
      [ "Ultra_Sense_Task", "class_ultra___sense___task_1_1_ultra___sense___task.html", null ]
    ] ],
    [ "XY_Tracking", null, [
      [ "XY_Tracking", "class_x_y___tracking_1_1_x_y___tracking.html", null ]
    ] ]
];