var class_m_e405_01_term_01_project_01v5_1_1_main =
[
    [ "main", "class_m_e405_01_term_01_project_01v5_1_1_main.html#a22e913e2e002fd9143e94c8edc7c532b", null ],
    [ "calibrated", "class_m_e405_01_term_01_project_01v5_1_1_main.html#a8b0c07e1d2a57d0f0d45405a75c3a0c5", null ],
    [ "ctrlState", "class_m_e405_01_term_01_project_01v5_1_1_main.html#a792bb45c9c6f6e642bac59cb860d6037", null ],
    [ "dataQueue", "class_m_e405_01_term_01_project_01v5_1_1_main.html#a5219642b067f4c015eaefbe0073d753c", null ],
    [ "distance", "class_m_e405_01_term_01_project_01v5_1_1_main.html#a95fbbfcf64903ea6a60cbdef3464daf3", null ],
    [ "encoderPosition", "class_m_e405_01_term_01_project_01v5_1_1_main.html#a1057665b62392910647de16e33318c6d", null ],
    [ "heading", "class_m_e405_01_term_01_project_01v5_1_1_main.html#ab5b17535b2776f3367a2047ec5b5ac71", null ],
    [ "kDShare", "class_m_e405_01_term_01_project_01v5_1_1_main.html#a019475560b5f59d1a5d1e99af3e2cb5a", null ],
    [ "kIShare", "class_m_e405_01_term_01_project_01v5_1_1_main.html#a70a8704d4b7ffbcd2ea7622fb8708073", null ],
    [ "kPShare", "class_m_e405_01_term_01_project_01v5_1_1_main.html#aeebdc826d9c59e922144eef47645c1fb", null ],
    [ "leftEncoder", "class_m_e405_01_term_01_project_01v5_1_1_main.html#a2962256396b645e0affd46f031401df8", null ],
    [ "leftMotor", "class_m_e405_01_term_01_project_01v5_1_1_main.html#ab652df5d5136a399db90f19bcebdff3e", null ],
    [ "lineSpeed", "class_m_e405_01_term_01_project_01v5_1_1_main.html#a48c9ae7762dbe68f85a3ff4beac98bb9", null ],
    [ "offset", "class_m_e405_01_term_01_project_01v5_1_1_main.html#a921cd6c8c71a6a7fc7b92452d62e4fee", null ],
    [ "rightEncoder", "class_m_e405_01_term_01_project_01v5_1_1_main.html#aacddd036a22899296564ed2a58f4fd15", null ],
    [ "rightMotor", "class_m_e405_01_term_01_project_01v5_1_1_main.html#acd981f65c9be485438e38bfc6b508156", null ],
    [ "strength", "class_m_e405_01_term_01_project_01v5_1_1_main.html#a7b6c0e1bcc722f49ce77a44f533f6538", null ],
    [ "targetPosition", "class_m_e405_01_term_01_project_01v5_1_1_main.html#a442af6a330179f3e3691742a2e8a0c4f", null ],
    [ "targetVelocity", "class_m_e405_01_term_01_project_01v5_1_1_main.html#a164ede44e70ecd8138219d44652dd4ad", null ],
    [ "xPosition", "class_m_e405_01_term_01_project_01v5_1_1_main.html#aee7eb3e7d3e7ba07135b3d642ded3105", null ],
    [ "yPosition", "class_m_e405_01_term_01_project_01v5_1_1_main.html#ab85fcdd0b30a41ead425b848fb928bad", null ]
];