var files_dup =
[
    [ "Com_Task.py", "_com___task_8py_source.html", null ],
    [ "Controller.py", "_controller_8py_source.html", null ],
    [ "Encoder.py", "_encoder_8py_source.html", null ],
    [ "IMU_Tracker.py", "_i_m_u___tracker_8py_source.html", null ],
    [ "IR_Sense_Task.py", "_i_r___sense___task_8py_source.html", null ],
    [ "ME405 Term Project v5.py", "_m_e405_01_term_01_project_01v5_8py_source.html", null ],
    [ "Motor.py", "_motor_8py_source.html", null ],
    [ "Motor_Task.py", "_motor___task_8py_source.html", null ],
    [ "PID.py", "_p_i_d_8py_source.html", null ],
    [ "Ultra_Sense_Task.py", "_ultra___sense___task_8py_source.html", null ],
    [ "XY_Tracking.py", "_x_y___tracking_8py_source.html", null ]
];