var index =
[
    [ "Hello! Welcome to our Mechatronics Term Project. Created by Evan Long and Sydney Alexander.", "index.html#autotoc_md0", [
      [ "Links to Each 11 Classes:", "index.html#autotoc_md1", null ],
      [ "Class Descriptions for Context:", "index.html#autotoc_md2", null ],
      [ "Overall Task Diagram:", "index.html#autotoc_md3", null ],
      [ "State Space Diagrams:", "index.html#autotoc_md4", [
        [ "Top Level Control:", "index.html#autotoc_md5", null ],
        [ "Course Controller:", "index.html#autotoc_md6", null ],
        [ "Sensor Driver (Abstract):", "index.html#autotoc_md7", null ]
      ] ]
    ] ]
];