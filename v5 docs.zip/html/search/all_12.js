var searchData=
[
  ['ultra_5fsense_5ftask_0',['Ultra_Sense_Task',['../class_ultra___sense___task_1_1_ultra___sense___task.html',1,'Ultra_Sense_Task']]]
];
