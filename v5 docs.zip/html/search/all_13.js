var searchData=
[
  ['welcome_20to_20our_20mechatronics_20term_20project_20created_20by_20evan_20long_20and_20sydney_20alexander_0',['Hello! Welcome to our Mechatronics Term Project.  Created by Evan Long and Sydney Alexander.',['../index.html#autotoc_md0',1,'']]]
];
