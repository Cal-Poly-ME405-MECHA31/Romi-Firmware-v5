var searchData=
[
  ['by_20evan_20long_20and_20sydney_20alexander_0',['Hello! Welcome to our Mechatronics Term Project.  Created by Evan Long and Sydney Alexander.',['../index.html#autotoc_md0',1,'']]]
];
