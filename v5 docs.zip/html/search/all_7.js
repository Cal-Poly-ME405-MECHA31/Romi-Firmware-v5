var searchData=
[
  ['for_20context_3a_0',['Class Descriptions for Context:',['../index.html#autotoc_md2',1,'']]]
];
