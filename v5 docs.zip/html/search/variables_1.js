var searchData=
[
  ['dataqueue_0',['dataQueue',['../class_m_e405_01_term_01_project_01v5_1_1_main.html#a5219642b067f4c015eaefbe0073d753c',1,'ME405 Term Project v5::Main']]],
  ['der_5fave_1',['DER_AVE',['../class_controller_1_1_controller.html#a48d29c3bc570c6d8f715c9f2ae5f403e',1,'Controller::Controller']]],
  ['distance_2',['distance',['../class_m_e405_01_term_01_project_01v5_1_1_main.html#a95fbbfcf64903ea6a60cbdef3464daf3',1,'ME405 Term Project v5::Main']]]
];
